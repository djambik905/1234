"use client";

import { useEffect, useRef } from "react";

/**
 * Attaches IntersectionObserver to a container ref.
 * When the container enters the viewport, all `.fadeinup` children
 * get the `.visible` class added (staggered by `staggerMs` per child).
 */
export function useFadeInUp(staggerMs = 120) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const items = Array.from(el.querySelectorAll<HTMLElement>(".fadeinup"));
    if (items.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          items.forEach((item, i) => {
            const delay = parseFloat(item.dataset.animateDelay || "0") * 1000 + i * staggerMs;
            setTimeout(() => item.classList.add("visible"), delay);
          });
          observer.disconnect();
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -80px 0px" }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [staggerMs]);

  return ref;
}
