import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { lastName, firstName, attendance } = await req.json();

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    return NextResponse.json({ error: "Bot not configured" }, { status: 500 });
  }

  const text =
    `📋 *Анкета гостя*\n` +
    `👤 Фамилия: ${lastName || "—"}\n` +
    `👤 Имя: ${firstName || "—"}\n` +
    `✅ Присутствие: ${attendance || "—"}`;

  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: "Markdown",
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    return NextResponse.json({ error: err }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
