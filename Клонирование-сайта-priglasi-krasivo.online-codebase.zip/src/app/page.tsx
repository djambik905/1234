import HeroSection from "@/components/sections/hero";
import WelcomeSection from "@/components/sections/welcome";
import LocationSection from "@/components/sections/location";
import TimingSection from "@/components/sections/timing";
import RsvpForm from "@/components/sections/rsvp-form";
import PhotoSection from "@/components/sections/photo-link";
import CountdownSection from "@/components/sections/countdown";

export default function Home() {
  return (
      <main
        style={{
          width: "100%",
          maxWidth: 640,
          margin: "0 auto",
          backgroundColor: "transparent",
          overflowX: "hidden",
        }}
      >
      <HeroSection />
      <WelcomeSection />
      <LocationSection />
      <TimingSection />

      <RsvpForm />
      <PhotoSection />
      <CountdownSection />
    </main>
  );
}
