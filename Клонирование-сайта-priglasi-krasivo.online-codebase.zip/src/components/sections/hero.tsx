"use client";

import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";

const PHOTO_URL = "/bg.jpg";

const MUSIC_URL =
  "https://dl.dropbox.com/s/fi/24iuw23758ap5moal23u5/Sting_-_Shape_Of_My_Heart_47835291.mp3?rlkey=kja9vfhyyn4e2eo9e5fgt5220&st=3mmnduz8&dl=0";

export default function HeroSection() {
  const [preloaderDone, setPreloaderDone] = useState(false);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Preloader: hide after ~1.8s (matches stripe animation end)
  useEffect(() => {
    const t = setTimeout(() => setPreloaderDone(true), 2800);
    return () => clearTimeout(t);
  }, []);

  // Music auto-play on first interaction
  useEffect(() => {
    const tryPlay = () => {
      const audio = audioRef.current;
      if (!audio || playing) return;
      audio.volume = 0;
      audio
        .play()
        .then(() => {
          setPlaying(true);
          let vol = 0;
          const fade = setInterval(() => {
            vol = Math.min(vol + 0.02, 0.4);
            audio.volume = vol;
            if (vol >= 0.4) clearInterval(fade);
          }, 50);
        })
        .catch(() => {});
    };
    const events = ["click", "touchstart", "scroll", "mousemove", "keydown"] as const;
    events.forEach((e) => window.addEventListener(e, tryPlay, { once: true, passive: true }));
    tryPlay();
    return () => events.forEach((e) => window.removeEventListener(e, tryPlay));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleMusic = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
    } else {
      audio.volume = 0;
      audio.play().then(() => {
        setPlaying(true);
        let vol = 0;
        const fade = setInterval(() => {
          vol = Math.min(vol + 0.02, 0.4);
          audio.volume = vol;
          if (vol >= 0.4) clearInterval(fade);
        }, 50);
      });
    }
  };

  return (
    <>
      {/* Preloader stripes — 13 black stripes that slide out left-to-right */}
      {!preloaderDone && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 9999,
            display: "flex",
            overflow: "hidden",
            pointerEvents: "none",
          }}
        >
          {Array.from({ length: 13 }).map((_, i) => (
            <div
              key={i}
              style={{
                flex: 1,
                background: "#000",
                animation: `preloaderOut 0.5s cubic-bezier(0.98,0.12,0.18,1.03) ${1.9 + i * 0.05}s forwards`,
              }}
            />
          ))}
        </div>
      )}

      <audio ref={audioRef} src={MUSIC_URL} preload="auto" loop />

      {/* Music toggle — fixed bottom-right */}
      <button
        onClick={toggleMusic}
        aria-label={playing ? "Pause music" : "Play music"}
        style={{
          position: "fixed",
          bottom: 24,
          right: 24,
          zIndex: 200,
          width: 44,
          height: 44,
          borderRadius: "50%",
          background: "#000",
          border: "none",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: 0.75,
        }}
      >
        {playing ? (
          <svg width="16" height="16" viewBox="0 0 16 16" fill="white">
            <rect x="3" y="2" width="4" height="12" rx="1" />
            <rect x="9" y="2" width="4" height="12" rx="1" />
          </svg>
        ) : (
          <svg width="16" height="16" viewBox="0 0 16 16" fill="white">
            <polygon points="3,2 13,8 3,14" />
          </svg>
        )}
      </button>

      {/* Fixed background photo — stays in place while all sections scroll over it */}
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100vh",
          zIndex: 0,
          pointerEvents: "none",
        }}
      >
        <Image
          src={PHOTO_URL}
          alt="Couple"
          fill
          sizes="100vw"
          style={{ objectFit: "cover", objectPosition: "center top" }}
          priority
        />
      </div>

      {/* Hero section — 632px, transparent (photo shows through from fixed layer) */}
      <section
        style={{
          position: "relative",
          width: "100%",
          height: 632,
          overflow: "visible",
          zIndex: 1,
        }}
      >
        {/* Dark glow behind "ПРИГЛАШЕНИЕ" title */}
        <div
          style={{
            position: "absolute",
            top: 30,
            left: "calc(50% - 114px)",
            width: 229,
            height: 23,
            background: "#000000",
            filter: "blur(35px)",
            zIndex: 2,
          }}
        />

        {/* Dark glow behind names */}
        <div
          style={{
            position: "absolute",
            top: 476,
            left: "calc(50% - 85px)",
            width: 171,
            height: 111,
            background: "#000000",
            filter: "blur(50px)",
            zIndex: 2,
          }}
        />

        {/* All text — z-index 3 so it sits above glow */}
        <div style={{ position: "relative", zIndex: 3 }}>
          {/* "ПРИГЛАШЕНИЕ НА СВАДЬБУ" */}
          <div
            style={{
              position: "absolute",
              top: 30,
              left: 0,
              right: 0,
              textAlign: "center",
                  fontFamily: "'Russische Elsevier', serif",
                  fontSize: 21,
                  fontWeight: "normal",
                  lineHeight: 1.55,
                  textTransform: "uppercase",
                  color: "#ffffff",
                  letterSpacing: "0.15em",
            }}
          >
                WEDDING DAY
            </div>

            {/* "02 | 05 | 2026" */}
            <div
              style={{
                position: "absolute",
                  top: 60,
                  left: 0,
                  right: 0,
                  textAlign: "center",
                    fontFamily: "'Russische Elsevier', serif",
                      fontSize: 18,
                  fontWeight: 400,
                  color: "#ffffff",
                  letterSpacing: "0.12em",
                opacity: 0.85,
              }}
            >
                2 МАЯ 2026
            </div>

              {/* "АНТОН" */}
            <div
              style={{
                position: "absolute",
                top: 470,
                left: 0,
                right: 0,
                textAlign: "center",
                fontFamily: "'Russische Elsevier', serif",
                fontSize: 36,
                fontWeight: "normal",
                lineHeight: 1.14,
                color: "#ffffff",
              }}
            >
              АНТОН
            </div>

              {/* "&" */}
              <div
                style={{
                  position: "absolute",
                  top: 511,
                  left: 0,
                  right: 0,
                  textAlign: "center",
                  fontFamily: "'Russische Elsevier', serif",
                  fontSize: 20,
                  fontWeight: "normal",
                  lineHeight: 2.05,
                  color: "#ffffff",
                }}
              >
                &
              </div>

              {/* "ИРИНА" */}
              <div
                style={{
                  position: "absolute",
                  top: 552,
                  left: 0,
                  right: 0,
                  textAlign: "center",
                  fontFamily: "'Russische Elsevier', serif",
                  fontSize: 36,
                  fontWeight: "normal",
                  lineHeight: 1.14,
                  color: "#ffffff",
                }}
              >
                ИРИНА
            </div>
        </div>
      </section>
    </>
  );
}
