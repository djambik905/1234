"use client";

import React from "react";
import { useFadeInUp } from "@/hooks/use-fade-in-up";

const garamond = "'Cormorant Garamond', 'Garamond', Georgia, serif";

function HLine() {
  return (
    <svg width="68" height="2" viewBox="0 0 69 2" style={{ display: "block", margin: "0 auto" }}>
      <path d="M1 1C1 1 68 1 68 1" stroke="#000000" strokeWidth="1" fill="transparent" />
    </svg>
  );
}

const rows = [
  { time: "14:30", label: "Сбор гостей" },
  { time: "15:00", label: "Венчание" },
  { time: "17:00", label: "Банкет" },
  { time: "21:00", label: "Завершение\nвечера" },
];

export default function TimingSection() {
  const ref = useFadeInUp(80);

  return (
    <section
      style={{
        position: "relative",
        width: "100%",
        zIndex: 1,
      }}
    >
      {/* White 80% overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundColor: "#ffffff",
          opacity: 0.8,
        }}
      />
      <div
        ref={ref}
        style={{
          position: "relative",
          width: 320,
          margin: "0 auto",
          paddingTop: 50,
          paddingBottom: 50,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 24,
        }}
      >
        {/* Заголовок */}
        <div
          className="fadeinup"
          style={{
              fontFamily: "'Russische Elsevier', serif",
              fontSize: 24,
              fontWeight: 400,
              lineHeight: 1.71,
              color: "#000000",
              textAlign: "center",
          }}
        >
          ТАЙМИНГ
        </div>

        {rows.map((row, i) => (
          <React.Fragment key={i}>
            <div className="fadeinup" style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <HLine />
              <div
                style={{
                  fontFamily: "'Russische Elsevier', serif",
                  fontSize: 27,
                  fontWeight: 400,
                  lineHeight: 1.2,
                  color: "#000000",
                  textAlign: "center",
                }}
              >
                {row.time}
              </div>
              <div
                style={{
                  fontFamily: garamond,
                  fontSize: 18,
                  fontWeight: 400,
                  lineHeight: 1.1,
                  color: "#000000",
                  textAlign: "center",
                  whiteSpace: "pre-line",
                }}
              >
                {row.label}
              </div>
            </div>
          </React.Fragment>
        ))}
      </div>
    </section>
  );
}
