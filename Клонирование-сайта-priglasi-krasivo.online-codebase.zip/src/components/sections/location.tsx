"use client";

import React from "react";
import Image from "next/image";
import { useFadeInUp } from "@/hooks/use-fade-in-up";

const garamond = "'Cormorant Garamond', 'Garamond', Georgia, serif";

const VENUE_IMG = "/location-venue.jpg";

export default function LocationSection() {
  const ref = useFadeInUp(100);

  return (
      <section
        style={{
          position: "relative",
          width: "100%",
          height: 452,
          zIndex: 1,
        }}
      >
        {/* White 80% overlay — full width */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundColor: "#ffffff",
            opacity: 0.8,
          }}
        />
        <div
          ref={ref}
          style={{ position: "relative", width: 320, margin: "0 auto", height: "100%" }}
        >

        {/* "Локация" — top=50, left=97, w=126, fs=24, fw=100, center */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 50,
            left: 97,
            width: 126,
            fontFamily: "'Russische Elsevier', serif",
            fontSize: 24,
            fontWeight: 100,
            lineHeight: 1.71,
            color: "#000000",
            textAlign: "center",
          }}
        >
          ЛОКАЦИЯ
        </div>

        {/* Address text — top=111, left=48, w=224, fs=16, fw=400, center */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 111,
            left: 48,
            width: 224,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
            Усадьба LA VILLA
            <br />
            д. Новинка ул. Центральная д.17
        </div>

        {/* Venue image — top=192, left=0, w=320, h=173 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 192,
            left: 0,
            width: 320,
            height: 173,
            overflow: "hidden",
          }}
        >
          <Image
            src={VENUE_IMG}
            alt="Venue"
            fill
            sizes="320px"
            style={{ objectFit: "cover" }}
          />
        </div>

        {/* Map button — top=332, left=127, w=65, h=65, bg=#000, border-radius=50% */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 332,
            left: 127,
            width: 65,
            height: 65,
            zIndex: 5,
          }}
        >
          <a
              href="https://yandex.ru/maps/?ll=27.297035,53.747868&z=16&pt=27.297035,53.747868"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "flex",
              width: 65,
              height: 65,
              borderRadius: "50%",
              backgroundColor: "#000000",
              alignItems: "center",
              justifyContent: "center",
              textDecoration: "none",
            }}
          >
            <span
              style={{
                fontFamily: garamond,
                fontSize: 8,
                fontWeight: 400,
                color: "#ffffff",
                textTransform: "uppercase",
                textAlign: "center",
                letterSpacing: "0.05em",
                lineHeight: 1.5,
                padding: "0 6px",
              }}
            >
              посмотреть
              <br />
              на карте
            </span>
          </a>
        </div>
      </div>
    </section>
  );
}
