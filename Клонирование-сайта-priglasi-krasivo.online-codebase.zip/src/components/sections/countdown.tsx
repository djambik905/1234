"use client";

import React, { useState, useEffect, useRef } from "react";

const COUNTDOWN_IMG = "/countdown.jpg";

const cormorant = "'Cormorant Garamond', 'Garamond', Georgia, serif";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export default function CountdownSection() {
  const triggerRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const target = new Date("2026-05-02T12:00:00");
    const calc = () => {
      const diff = +target - +new Date();
      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    };
    calc();
    const t = setInterval(calc, 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const el = triggerRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const units = [
    { value: timeLeft.days, label: "ДНЕЙ" },
    { value: timeLeft.hours, label: "ЧАСОВ" },
    { value: timeLeft.minutes, label: "МИНУТ" },
    { value: timeLeft.seconds, label: "СЕКУНД" },
  ];

    return (
      <section
        style={{
          position: "relative",
          width: "100%",
          height: 647,
          backgroundColor: "#ffffff",
          zIndex: 1,
          overflow: "hidden",
        }}
      >
          {/* Background photo full-width, full-height */}
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundImage: `url('${COUNTDOWN_IMG}')`,
                backgroundSize: "cover",
                backgroundPosition: "center top",
              }}
            />
            {/* Gradient: white at top fading into transparent — smooth transition from previous section */}
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                height: 120,
                background: "linear-gradient(to bottom, rgba(255,255,255,1) 0%, rgba(255,255,255,0) 100%)",
                zIndex: 1,
                pointerEvents: "none",
              }}
            />

          <div
            style={{
              position: "relative",
              width: 320,
              margin: "0 auto",
              height: 647,
            }}
          >
            {/* Trigger observer at this point (middle of section) */}
            <div ref={triggerRef} style={{ position: "absolute", top: 400, height: 1 }} />

            {/* "до встречи через:" */}
            <div
              style={{
                position: "absolute",
                top: 467,
                left: 39,
                width: 243,
                fontFamily: cormorant,
                fontSize: 20,
                fontWeight: 100,
                lineHeight: 1,
                color: "#ffffff",
                textAlign: "center",
                textTransform: "uppercase",
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(20px)",
                transition: "opacity 0.8s ease 0.2s, transform 0.8s ease 0.2s",
              }}
            >
              до встречи через:
            </div>

            {/* Timer */}
            <div
              style={{
                position: "absolute",
                top: 515,
                left: 0,
                width: 320,
                height: 77,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 0,
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(20px)",
                transition: "opacity 0.8s ease 0.5s, transform 0.8s ease 0.5s",
              }}
            >
          {units.map((u, i) => (
            <React.Fragment key={u.label}>
              {i > 0 && (
                <div
                  style={{
                    width: 1,
                    height: 40,
                    background: "rgba(255,255,255,0.4)",
                    margin: "0 8px",
                  }}
                />
              )}
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <div
                  style={{
                    width: 48,
                    height: 48,
                    border: "1px solid #ffffff",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <span
                    style={{
                      fontFamily: cormorant,
                      fontSize: 20,
                      fontWeight: 100,
                      color: "#ffffff",
                      lineHeight: 1,
                    }}
                  >
                    {u.value}
                  </span>
                </div>
                <span
                  style={{
                    fontFamily: "Arial, sans-serif",
                    fontSize: 7,
                    fontWeight: 400,
                    color: "#ffffff",
                    textTransform: "uppercase",
                    letterSpacing: "0.05em",
                  }}
                >
                  {u.label}
                </span>
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
}
