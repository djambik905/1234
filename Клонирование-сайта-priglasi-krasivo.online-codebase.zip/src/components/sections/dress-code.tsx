"use client";

import React from "react";
import { useFadeInUp } from "@/hooks/use-fade-in-up";

const garamond = "'Cormorant Garamond', 'Garamond', Georgia, serif";

// Swatches from original: left=58,98,140,179,221; w=40,42,39,42,40; h=90 each; top=206
const swatches = [
  { left: 58,  width: 40, color: "#000000" },
  { left: 98,  width: 42, color: "#2b2219" },
  { left: 140, width: 39, color: "#634e3c" },
  { left: 179, width: 42, color: "#b09c77" },
  { left: 221, width: 40, color: "#e7e4db" },
];

export default function DressCodeSection() {
  const ref = useFadeInUp(80);

  return (
      <section
        style={{
          position: "relative",
          width: "100%",
          height: 420,
          zIndex: 1,
        }}
      >
        {/* White 80% overlay — full width */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundColor: "#ffffff",
            opacity: 0.8,
          }}
        />
        <div
          ref={ref}
          style={{ position: "relative", width: 320, margin: "0 auto", height: "100%" }}
        >

        {/* "Дресс-код" — top=50, left=88, w=143, fs=24, fw=100 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 50,
            left: 88,
            width: 143,
            fontFamily: garamond,
            fontSize: 24,
            fontWeight: 100,
            lineHeight: 1.71,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Дресс-код
        </div>

        {/* Description — top=111, left=13, w=294, fs=16, fw=400 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 111,
            left: 13,
            width: 294,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Мы будем рады видеть вас в любом наряде, но нам будет еще приятнее, если вы
          поддержите общую гамму нашего торжества.
        </div>

        {/* Color swatches — top=206, staggered delays */}
        {swatches.map((s, i) => (
          <div
            key={i}
            className="fadeinup"
            data-animate-delay={String(i * 0.2)}
            style={{
              position: "absolute",
              top: 206,
              left: s.left,
              width: s.width,
              height: 90,
              backgroundColor: s.color,
            }}
          />
        ))}

        {/* "Девушки..." — top=316, left=11, w=299, fs=16, fw=400, center */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 316,
            left: 11,
            width: 299,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Девушки: вечерние и коктейльные платья
        </div>

        {/* "Мужчины..." — top=350, left=0, w=320, fs=16, fw=400, center */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 350,
            left: 0,
            width: 320,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Мужчины: костюм или рубашка + брюки
        </div>
      </div>
    </section>
  );
}
