"use client";

import React, { useState } from "react";
import { useFadeInUp } from "@/hooks/use-fade-in-up";

const serif = "'Cormorant Garamond', 'Garamond', Georgia, serif";

export default function RsvpForm() {
  const ref = useFadeInUp(0);
  const [lastName, setLastName] = useState("");
  const [firstName, setFirstName] = useState("");
  const [attendance, setAttendance] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const inputStyle: React.CSSProperties = {
    width: "100%",
    borderBottom: "1px solid #000000",
    borderTop: "none",
    borderLeft: "none",
    borderRight: "none",
    outline: "none",
    background: "transparent",
    fontFamily: serif,
    fontSize: 14,
    fontWeight: 400,
    color: "#000000",
    padding: "6px 0",
    borderRadius: 0,
  };

  const labelStyle: React.CSSProperties = {
    fontFamily: serif,
    fontSize: 16,
    fontWeight: 400,
    color: "#2f2f2f",
    display: "block",
    marginBottom: 5,
  };

  const subtitleStyle: React.CSSProperties = {
    fontFamily: serif,
    fontSize: 12,
    fontWeight: 400,
    color: "#2f2f2f",
    marginBottom: 8,
  };

  return (
    // rec1023649361: height=814px, white 80% overlay
      <section
        style={{
          position: "relative",
          width: "100%",
          height: 580,
          zIndex: 1,
        }}
      >
        {/* White 80% overlay — full width */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundColor: "#ffffff",
            opacity: 0.8,
          }}
        />
        <div
          ref={ref}
          style={{ position: "relative", width: 320, margin: "0 auto", height: "100%" }}
        >

        {/* "Анкета гостя" — top=50, left=67, w=185, fs=24, fw=100 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 50,
            left: 67,
            width: 185,
            fontFamily: serif,
            fontSize: 24,
            fontWeight: 100,
            lineHeight: 1.71,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Анкета гостя
        </div>

        {/* Subtitle — top=111, left=13, w=294 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 111,
            left: 13,
            width: 294,
            fontFamily: serif,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Ваши ответы очень помогут в организации свадьбы. Ждем их до 10 августа!
        </div>

        {/* Form — top=168, left=19, w=283 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 168,
            left: 19,
            width: 283,
          }}
        >
          <form onSubmit={async (e) => {
            e.preventDefault();
            setLoading(true);
            setError("");
            try {
              const res = await fetch("/api/rsvp", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ lastName, firstName, attendance }),
              });
              if (!res.ok) throw new Error("Ошибка отправки");
              window.location.href = "https://t.me/+KpOpFVkg6o5mYTMy";
            } catch {
              setError("Не удалось отправить. Попробуйте ещё раз.");
            } finally {
              setLoading(false);
            }
          }}>
            {/* Фамилия */}
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Ваша фамилия</label>
              <input
                type="text"
                placeholder="Ивановы"
                style={inputStyle}
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
              />
            </div>

            {/* Имя */}
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Ваше имя</label>
              <p style={subtitleStyle}>
                если вы будете с парой или с семьей, то внесите все имена
              </p>
              <input
                type="text"
                placeholder="Дмитрий и София"
                style={inputStyle}
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
              />
            </div>

            {/* Присутствие */}
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Присутствие</label>
              {["Я приду", "К сожалению, не смогу", "Дам ответ чуть позже"].map((opt) => (
                <label
                  key={opt}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    cursor: "pointer",
                    marginBottom: 10,
                    fontFamily: serif,
                    fontSize: 14,
                    fontWeight: 400,
                    color: "#000000",
                    gap: 10,
                  }}
                >
                  <span
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      width: 16,
                      height: 16,
                      border: "1px solid #000",
                      borderRadius: "50%",
                      flexShrink: 0,
                    }}
                    onClick={() => setAttendance(opt)}
                  >
                    {attendance === opt && (
                      <span
                        style={{
                          width: 8,
                          height: 8,
                          borderRadius: "50%",
                          background: "#000",
                          display: "block",
                        }}
                      />
                    )}
                  </span>
                  <span onClick={() => setAttendance(opt)}>{opt}</span>
                </label>
              ))}
            </div>



            {/* Submit */}
            <div style={{ display: "flex", justifyContent: "center", flexDirection: "column", alignItems: "center", gap: 8 }}>
              {error && <p style={{ fontFamily: serif, fontSize: 13, color: "red", textAlign: "center" }}>{error}</p>}
              <button
                type="submit"
                disabled={loading}
                style={{
                  width: 200,
                  height: 30,
                  background: "#000000",
                  color: "#ffffff",
                  border: "none",
                  cursor: loading ? "not-allowed" : "pointer",
                  fontFamily: serif,
                  fontSize: 16,
                  fontWeight: 400,
                  letterSpacing: "0.05em",
                  borderRadius: 0,
                  opacity: loading ? 0.6 : 1,
                }}
              >
                {loading ? "Отправка..." : "Отправить"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
