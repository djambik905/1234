"use client";

import React from "react";
import { useFadeInUp } from "@/hooks/use-fade-in-up";

const garamond = "'Cormorant Garamond', 'Garamond', Georgia, serif";

export default function PhotoSection() {
  const ref = useFadeInUp(100);

  return (
    // rec1023649371: height=390 (overlay h=434), white 80% overlay
      <section
        style={{
          position: "relative",
          width: "100%",
          height: 390,
          zIndex: 1,
        }}
      >
          {/* White overlay — fades out at the bottom */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: "linear-gradient(to bottom, rgba(255,255,255,0.8) 50%, rgba(255,255,255,1) 100%)",
            }}
          />
        <div
          ref={ref}
          style={{ position: "relative", width: 320, margin: "0 auto", height: "100%" }}
        >

        {/* "пару моментов" — top=50, w=370, centered → left=-25 but clamped, use center */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 50,
            left: 0,
            width: 320,
            fontFamily: garamond,
            fontSize: 24,
            fontWeight: 100,
            lineHeight: 1.71,
            color: "#000000",
            textTransform: "uppercase",
            textAlign: "center",
          }}
        >
          пару моментов
        </div>

        {/* "-1-" — top=111, left=152, w=16, fs=16, fw=100 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 111,
            left: 152,
            width: 16,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 100,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          -1-
        </div>

        {/* Organizer text — top=141, w=333, centered */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 141,
            left: 0,
            width: 320,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
            padding: "0 10px",
          }}
        >
          По всем возникающим вопросам в день свадьбы, просьба обращаться к нашему
          свадебному организатору.
        </div>

        {/* "-2-" — top=254, left=150, w=18 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 254,
            left: 150,
            width: 18,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 100,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          -2-
        </div>

        {/* Photo link text — top=284, w=330, centered */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 284,
            left: 0,
            width: 320,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
            padding: "0 5px",
          }}
        >
          Позднее по этой ссылке вы сможете увидеть и сохранить на память все фото и
          видео нашего торжества.{" "}
          <a
            href="#"
            style={{
              color: "#000000",
              textDecoration: "none",
              borderBottom: "1px solid #000",
            }}
          >
            тут ссылочка
          </a>
        </div>
      </div>
    </section>
  );
}
