"use client";

import React from "react";
import { useFadeInUp } from "@/hooks/use-fade-in-up";

const garamond = "'Cormorant Garamond', 'Garamond', Georgia, serif";

export default function WelcomeSection() {
  const ref = useFadeInUp(100);

  return (
    <section
      style={{
        position: "relative",
        width: "100%",
          height: 380,
        overflow: "visible",
        zIndex: 1,
      }}
    >
        {/* Gradient overlay: transparent at top → white 80% at bottom */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(255,255,255,0.8) 35%)",
          }}
        />
      <div ref={ref} style={{ position: "relative", width: 320, margin: "0 auto", height: "100%" }}>

        {/* "Дорогие гости!" — top=100, left=51, w=219, fs=24, fw=100 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 100,
            left: 51,
            width: 219,
            fontFamily: "'Russische Elsevier', serif",
            fontSize: 24,
            fontWeight: 100,
            lineHeight: 1.71,
            color: "#000000",
            textAlign: "center",
          }}
          >
            Дорогие гости!
        </div>

        {/* Para 1: top=161, left=5, w=310 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 161,
            left: 5,
            width: 310,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
            Мы счастливы пригласить вас на самый важный день в нашей жизни — нашу свадьбу!
        </div>

        {/* Para 2: top=237, left=5 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 237,
            left: 5,
            width: 310,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          В этот день мы хотим быть в окружении самых близких и дорогих людей.
        </div>

          {/* Para 3: top=310, left=38, w=245 */}
        <div
          className="fadeinup"
          style={{
            position: "absolute",
            top: 310,
            left: 38,
            width: 245,
            fontFamily: garamond,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.6,
            color: "#000000",
            textAlign: "center",
          }}
        >
          Надеемся, что вы примете наше приглашение, будем вас ждать!
        </div>
      </div>
    </section>
  );
}
